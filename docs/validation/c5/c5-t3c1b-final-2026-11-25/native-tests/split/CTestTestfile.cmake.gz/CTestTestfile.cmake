# CMake generated Testfile for 
# Source directory: /repo/docker/experiments/c5-t3c1a
# Build directory: /build/split
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(split-native-veto "/build/ipc-test")
set_tests_properties(split-native-veto PROPERTIES  _BACKTRACE_TRIPLES "/repo/docker/experiments/c5-t3c1a/CMakeLists.txt;22;add_test;/repo/docker/experiments/c5-t3c1a/CMakeLists.txt;0;")
