float32[] data
