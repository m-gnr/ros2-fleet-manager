"""Required configuration fields; no implicit operational defaults."""

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .warehouse import WarehouseLayout

Identifier = Annotated[str, Field(pattern=r"^[A-Za-z_][A-Za-z0-9_]*$")]
RosName = Annotated[str, Field(pattern=r"^/[A-Za-z_][A-Za-z0-9_]*(/[A-Za-z_][A-Za-z0-9_]*)*$")]
Text = Annotated[str, Field(min_length=1, pattern=r"\S")]
Positive = Annotated[float, Field(gt=0)]
NonNegative = Annotated[float, Field(ge=0)]
Percent = Annotated[float, Field(ge=0, le=100)]


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False)


class Pose(Contract):
    x: float = Field(description="X position in map frame, metres.")
    y: float = Field(description="Y position in map frame, metres.")
    yaw: float = Field(description="Heading in map frame, radians.")


class BatteryModel(Contract):
    usable_capacity_wh: Positive
    consumption_wh_per_meter: Positive
    idle_power_w: NonNegative
    charge_power_w: Positive


Vector3 = Annotated[list[float], Field(min_length=3, max_length=3)]
Size3 = Annotated[list[Positive], Field(min_length=3, max_length=3)]


class ObstacleMount(Contract):
    id: Identifier
    position_m: Vector3
    yaw_rad: float


class ObstacleSensorAssembly(Contract):
    case_size_m: Size3
    case_mass_kg: Positive
    head_mass_kg: Positive
    head_radius_m: Positive
    head_height_m: Positive
    head_center_m: Vector3
    beam_origin_m: Vector3
    horizontal_min_rad: float
    horizontal_max_rad: float
    samples: Annotated[int, Field(ge=2)]
    update_rate_hz: Positive
    min_range_m: NonNegative
    max_range_m: Positive
    range_resolution_m: Positive
    mounts: Annotated[list[ObstacleMount], Field(min_length=2, max_length=2)]

    @model_validator(mode="after")
    def ordered_sensor_contract(self):
        from math import pi
        if not -pi <= self.horizontal_min_rad < self.horizontal_max_rad <= pi:
            raise ValueError("obstacle sensor: require -pi <= min angle < max angle <= pi")
        if self.min_range_m >= self.max_range_m:
            raise ValueError("obstacle sensor: min range must be below max range")
        if len({m.id for m in self.mounts}) != len(self.mounts):
            raise ValueError("obstacle sensor: duplicate mount id")
        if self.beam_origin_m[2] <= max(self.case_size_m[2]/2, self.head_center_m[2]+self.head_height_m/2):
            raise ValueError("obstacle sensor: beam plane must be above finite opaque housing")
        return self


class PerceptionMotionEnvelope(Contract):
    evidence_sha256: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    max_linear_speed_m_s: Positive
    max_angular_speed_rad_s: Positive
    minimum_detection_distance_m: Positive
    maximum_stop_distance_m: Positive
    maximum_stop_angle_rad: Positive
    cancel_terminal_sec: Positive
    footprint_radius_m: Positive
    margin_m: Positive


class PerceptionSafety(Contract):
    scan_age_sec: Positive
    transport_sec: Positive
    clock_pause_sec: Positive
    clock_step_sec: Positive
    watchdog_gap_sec: Positive
    timer_period_sec: Positive
    observation_age_sec: Positive
    tf_wait_sec: Positive
    linear_stop_threshold_m_s: Positive
    angular_stop_threshold_rad_s: Positive
    odometry_freshness_sec: Positive
    cancel_stop_timeout_sec: Positive
    motion_envelope: PerceptionMotionEnvelope | None = Field(default_factory=lambda: None)

    @model_validator(mode="after")
    def bounded_timer(self):
        if self.timer_period_sec >= self.watchdog_gap_sec:
            raise ValueError("perception timer period must be below scheduling gap limit")
        if self.tf_wait_sec > min(self.scan_age_sec, self.transport_sec):
            raise ValueError("measurement TF wait must fit scan and transport budgets")
        if self.motion_envelope:
            e = self.motion_envelope
            # This arithmetic is necessary, never sufficient qualification.
            travel = e.max_linear_speed_m_s * (max(self.scan_age_sec, self.observation_age_sec,
                       self.transport_sec) + self.watchdog_gap_sec + e.cancel_terminal_sec)
            required = travel + e.maximum_stop_distance_m + e.footprint_radius_m * e.maximum_stop_angle_rad + e.margin_m
            if required >= e.minimum_detection_distance_m:
                raise ValueError("perception stop envelope does not fit minimum detection distance")
        return self


class Fleet(Contract):
    name: Text
    map_path: Text = Field(description="Map YAML relative to this file, or 'warehouse:generated'.")
    use_sim_time: Literal[True]
    battery_models: Annotated[dict[Identifier, BatteryModel], Field(min_length=1)]
    obstacle_sensor_models: dict[Identifier, ObstacleSensorAssembly] = Field(default_factory=dict)
    perception_safety: PerceptionSafety | None = Field(default_factory=lambda: None)

    @field_validator("use_sim_time", mode="before")
    @classmethod
    def boolean_clock(cls, value):
        if type(value) is not bool:
            raise ValueError("use_sim_time must be a boolean")
        return value


class Robot(Contract):
    id: Identifier
    name: Text
    namespace: RosName
    initial_pose: Pose
    battery_model: Identifier
    nav2_action_name: RosName
    nav2_params_path: Text = Field(description="Nav2 template path relative to fleet YAML.")
    obstacle_sensor_model: Identifier | None = Field(default_factory=lambda: None)

    @model_validator(mode="after")
    def isolated_action(self):
        if not self.nav2_action_name.startswith(self.namespace + "/"):
            raise ValueError("nav2_action_name must belong to the robot namespace")
        return self


class Station(Contract):
    id: Identifier
    pose: Pose


class ChargingStation(Station):
    tolerance_radius: Positive = Field(description="Dock contact region radius, metres.")


class Stations(Contract):
    charging_stations: Annotated[list[ChargingStation], Field(min_length=1)]
    parking_stations: list[Station]
    safe_waiting_areas: list[Station]


class Policies(Contract):
    assignment: Literal["priority_fifo_nearest_eligible"]
    preemption_priority: Literal["HIGH"]
    max_preemptions: Literal[2]
    extra_swap_enabled: Literal[False]
    automatic_retry: Literal[False]
    automatic_reassignment: Literal[False]
    charge_target_soc_percent: Literal[80]
    charge_queue: Literal["lowest_soc_fifo"]
    emergency_soc_percent: Percent
    low_soc_percent: Percent
    safety_margin_wh: NonNegative

    @field_validator("extra_swap_enabled", "automatic_retry", "automatic_reassignment", mode="before")
    @classmethod
    def boolean_policy(cls, value):
        if type(value) is not bool:
            raise ValueError("policy flag must be a boolean")
        return value

    @model_validator(mode="after")
    def energy_thresholds(self):
        if not self.emergency_soc_percent < self.low_soc_percent < self.charge_target_soc_percent:
            raise ValueError("require emergency_soc_percent < low_soc_percent < charge_target_soc_percent")
        return self


class FleetConfig(Contract):
    fleet: Fleet
    robots: Annotated[list[Robot], Field(min_length=1)]
    stations: Stations
    policies: Policies
    warehouse: WarehouseLayout | None = Field(default_factory=lambda: None)

    @model_validator(mode="after")
    def references_and_ownership(self):
        for field in ("id", "name", "namespace", "nav2_action_name"):
            values = [getattr(robot, field) for robot in self.robots]
            if len(set(values)) != len(values):
                raise ValueError(f"robots: duplicate {field}")
        namespaces = [robot.namespace for robot in self.robots]
        for index, namespace in enumerate(namespaces):
            for other in namespaces[index + 1:]:
                if namespace.startswith(other + "/") or other.startswith(namespace + "/"):
                    raise ValueError("robots: nested namespaces overlap")
        starts = [(r.initial_pose.x, r.initial_pose.y) for r in self.robots]
        if len(set(starts)) != len(starts):
            raise ValueError("robots: duplicate initial position")
        for robot in self.robots:
            if robot.obstacle_sensor_model is not None and robot.obstacle_sensor_model not in self.fleet.obstacle_sensor_models:
                raise ValueError(f"robots.{robot.id}.obstacle_sensor_model: unknown model")
            if robot.battery_model not in self.fleet.battery_models:
                raise ValueError(f"robots.{robot.id}.battery_model: unknown model {robot.battery_model}")
        for name, battery in self.fleet.battery_models.items():
            available = battery.usable_capacity_wh * (1 - self.policies.emergency_soc_percent / 100)
            if self.policies.safety_margin_wh >= available:
                raise ValueError(f"fleet.battery_models.{name}: safety margin exhausts usable energy after reserve")
        stations = (self.stations.charging_stations + self.stations.parking_stations
                    + self.stations.safe_waiting_areas)
        ids = [station.id for station in stations]
        if len(set(ids)) != len(ids):
            raise ValueError("stations: duplicate resource id across station groups")
        poses = [(station.pose.x, station.pose.y) for station in stations]
        if len(set(poses)) != len(poses):
            raise ValueError("stations: resources share the same physical position")
        if self.fleet.map_path == "warehouse:generated" and self.warehouse is None:
            raise ValueError("warehouse:generated requires warehouse geometry")
        if self.warehouse is not None:
            if not 2 <= len(self.stations.charging_stations) <= 6 or not self.stations.parking_stations:
                raise ValueError("warehouse profile requires two to six charging stations and a parking station")
            for kind, group in (("charging", self.stations.charging_stations),
                                ("parking", self.stations.parking_stations)):
                for station in group:
                    if not self.warehouse.zone(kind).contains(station.pose.x, station.pose.y, .4):
                        raise ValueError(f"{station.id}: resource pose is outside its warehouse zone")
            self.warehouse.check_service(self.stations.charging_stations, self.stations.parking_stations)
            transfer_ids = {point.id for point in self.warehouse.transfer_points}
            transfer_poses = {(point.pose.x, point.pose.y) for point in self.warehouse.transfer_points}
            if transfer_ids.intersection(ids) or transfer_poses.intersection(poses):
                raise ValueError("warehouse transfer points share an ID or position with a resource")
            if len(transfer_poses) != len(self.warehouse.transfer_points):
                raise ValueError("warehouse transfer points share a position")
        return self
