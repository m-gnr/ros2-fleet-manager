cmake_minimum_required(VERSION 3.8)
project(fleet_interfaces)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

find_package(ament_cmake REQUIRED)
find_package(rosidl_default_generators REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(nav_msgs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(sensor_msgs REQUIRED)
find_package(builtin_interfaces REQUIRED)
find_package(unique_identifier_msgs REQUIRED)

rosidl_generate_interfaces(${PROJECT_NAME}
  "action/ExecuteTask.action"
  "action/NavigateToStation.action"
  "msg/RobotStatus.msg"
  "msg/ObservationHealth.msg"
  "msg/BatteryState.msg"
  "msg/BatteryControlApplied.msg"
  "msg/DockLease.msg"
  "msg/TrafficPermitIdentity.msg"
  "msg/TrafficPermitDecision.msg"
  "msg/TrafficPermitAck.msg"
  "msg/TrafficChildObservation.msg"
  "srv/RequestTrafficPermit.srv"
  "srv/ClearRobotError.srv"
  "srv/ControlBattery.srv"
  DEPENDENCIES
    sensor_msgs
    geometry_msgs
    nav_msgs
    std_msgs
    builtin_interfaces
    unique_identifier_msgs
)

ament_export_dependencies(rosidl_default_runtime)
ament_package()
