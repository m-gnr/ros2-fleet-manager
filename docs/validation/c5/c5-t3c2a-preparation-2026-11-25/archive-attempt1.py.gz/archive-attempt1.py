from pathlib import Path
import gzip,hashlib,json,shutil
src=Path('/tmp/c5-t3c2a-20261125');out=Path('/Users/murat/develop/ros2-fleet-manager-demo/docs/validation/c5/c5-t3c2a-preparation-2026-11-25');out.mkdir(exist_ok=False)
manifest=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for source in sorted(src.rglob('*')):
 if not source.is_file():continue
 dest=out/source.relative_to(src);identity=source.suffix in ('.gz','.py')
 if not identity:dest=dest.with_name(dest.name+'.gz')
 dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
 if identity:shutil.copyfile(source,dest)
 else:
  with source.open('rb') as i,dest.open('wb') as raw:
   with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,compresslevel=6) as o:shutil.copyfileobj(i,o)
 manifest.append(dict(path=str(dest.relative_to(out)),original_sha256=sha(source),archive_sha256=sha(dest),encoding='identity' if identity else 'gzip',original_bytes=source.stat().st_size,archive_bytes=dest.stat().st_size))
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for e in manifest:
 f=out/e['path'];assert sha(f)==e['archive_sha256']
 data=gzip.open(f,'rb').read() if e['encoding']=='gzip' else f.read_bytes()
 assert hashlib.sha256(data).hexdigest()==e['original_sha256']
(out/'archive-verification.json').write_text(json.dumps(dict(files_verified=len(manifest),all_hashes_match=True,preparation='PASS',T3C2B='BLOCKED',new_gazebo_runs=0),indent=2)+'\n');print('archived/verified',len(manifest),'preparation evidence files')
