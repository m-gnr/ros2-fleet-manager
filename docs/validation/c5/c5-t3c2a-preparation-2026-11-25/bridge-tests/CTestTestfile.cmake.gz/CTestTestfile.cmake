# CMake generated Testfile for 
# Source directory: /workspace/docker/experiments/c5-t3c1b/lifetime
# Build directory: /build/lifecycle
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(bridge-owner-expires "/build/lifecycle/bridge-lifetime")
set_tests_properties(bridge-owner-expires PROPERTIES  _BACKTRACE_TRIPLES "/workspace/docker/experiments/c5-t3c1b/lifetime/CMakeLists.txt;12;add_test;/workspace/docker/experiments/c5-t3c1b/lifetime/CMakeLists.txt;0;")
