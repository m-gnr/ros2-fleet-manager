# CMake generated Testfile for 
# Source directory: /repo/docker/experiments/c5-t3c1b
# Build directory: /build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(health-receiver-and-final-veto "/build/health-test")
set_tests_properties(health-receiver-and-final-veto PROPERTIES  _BACKTRACE_TRIPLES "/repo/docker/experiments/c5-t3c1b/CMakeLists.txt;17;add_test;/repo/docker/experiments/c5-t3c1b/CMakeLists.txt;0;")
subdirs("split")
