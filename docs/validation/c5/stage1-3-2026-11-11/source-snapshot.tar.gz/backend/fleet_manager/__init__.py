"""Fleet Manager core package."""
