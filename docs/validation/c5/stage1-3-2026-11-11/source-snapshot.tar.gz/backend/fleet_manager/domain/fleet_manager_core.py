"""Pure Python Fleet Manager Core Engine.

Coordinates:
- Task Queue (Priority HIGH -> MED -> LOW, work-conserving FIFO, no aging)
- Fleet Tracker (RobotStatus 5 Hz updates, 2.0s stale exclusion, comm health)
- Reservation Manager (Station single ownership, physical departure, BLOCKED containment)
- Scheduler (Route distance, Wh energy, nearest idle robot, tie-breaking, safe preemption)
- Assignment & UUID/Epoch matching (Deduplication, stale result rejection)
"""

import logging
from typing import Dict, List, Optional, Tuple
import uuid

from .constants import (
    DEFAULT_CHARGE_TARGET_SOC,
    DEFAULT_EMERGENCY_SOC,
    DEFAULT_SAFETY_MARGIN_WH,
    COMMUNICATION_ALERT_SEC,
    COMMUNICATION_WARNING_SEC,
    ROBOT_STATUS_STALE_TIMEOUT_SEC,
    ReservationState,
    RobotState,
    StationType,
    TaskPhase,
    TaskPriority,
    TaskResultStatus,
    TaskStatus,
)
from .fleet_tracker import FleetTracker
from .models import (
    Assignment,
    Pose2D,
    PreemptionDecision,
    RobotBatterySpecs,
    RobotRecord,
    StationRecord,
    Task,
)
from .reservations import ReservationManager
from .scheduler import RouteDistanceProvider, Scheduler
from .station_dispatch import StationDispatch
from .task_queue import TaskQueue

logger = logging.getLogger(__name__)


class FleetManagerCore:
    """Central pure Python domain core for ROS 2 Fleet Manager."""

    def __init__(
        self,
        route_provider: RouteDistanceProvider,
        safe_charge_station_pose: Pose2D,
        *,
        emergency_soc_percent: float = DEFAULT_EMERGENCY_SOC,
        safety_margin_wh: float = DEFAULT_SAFETY_MARGIN_WH,
        low_soc_percent: float | None = None,
        charge_target_soc_percent: float = DEFAULT_CHARGE_TARGET_SOC,
    ) -> None:
        self.queue = TaskQueue()
        self.tracker = FleetTracker()
        self.reservations = ReservationManager()
        self.station_dispatch = (
            StationDispatch(low_soc_percent, charge_target_soc_percent) if low_soc_percent is not None else None
        )
        self.scheduler = Scheduler(
            route_provider=route_provider,
            safe_charge_station_pose=safe_charge_station_pose,
            emergency_soc_percent=emergency_soc_percent,
            safety_margin_wh=safety_margin_wh,
        )

        # Active tasks by task_id and by robot_id
        self._active_tasks: Dict[str, Task] = {}
        self._active_tasks_by_robot: Dict[str, Task] = {}

        # Preemption in progress: maps robot_id -> pending HIGH task
        self._pending_preemption_assignments: Dict[str, Task] = {}

        # History of completed / failed tasks
        self._completed_tasks: Dict[str, Task] = {}
        self._failed_tasks: Dict[str, Task] = {}

        # Tasks held for review due to explicit goal rejection (C3.3.2-DEC-03)
        self._review_holds: Dict[str, dict] = {}

    def has_review_hold(self, task_id: str) -> bool:
        """Return True if task is currently held for review."""
        return task_id in self._review_holds

    def add_review_hold(
        self,
        task_id: str,
        robot_id: str,
        assignment_epoch: int,
        goal_uuid: str,
        reason: str,
        held_at: float,
    ) -> None:
        """Place task on review hold following explicit goal rejection."""
        self._review_holds[task_id] = {
            "task_id": task_id,
            "robot_id": robot_id,
            "assignment_epoch": assignment_epoch,
            "goal_uuid": goal_uuid,
            "reason": reason,
            "held_at": held_at,
        }

    def clear_review_hold(self, task_id: str) -> bool:
        """Clear review hold on explicit operator intervention."""
        if task_id in self._review_holds:
            del self._review_holds[task_id]
            return True
        return False

    def list_review_holds(self) -> List[dict]:
        """List all active task review holds."""
        return list(self._review_holds.values())

    # -------------------------------------------------------------------------
    # Configuration / Registration
    # -------------------------------------------------------------------------
    def register_robot(
        self,
        robot_id: str,
        specs: Optional[RobotBatterySpecs] = None,
        initial_pose: Optional[Pose2D] = None,
        *,
        requires_battery_telemetry: bool = False,
    ) -> RobotRecord:
        """Register a robot from fleet configuration."""
        return self.tracker.register_robot(
            robot_id, specs=specs, initial_pose=initial_pose, requires_battery_telemetry=requires_battery_telemetry,
        )

    def register_station(
        self,
        station_id: str,
        station_type: StationType,
        pose: Pose2D,
        tolerance_radius: float = 0.30,
        departure_margin: float = 0.05,
    ) -> StationRecord:
        """Register a station or parking slot."""
        return self.reservations.register_station(
            station_id=station_id,
            station_type=station_type,
            pose=pose,
            tolerance_radius=tolerance_radius,
            departure_margin=departure_margin,
        )

    # -------------------------------------------------------------------------
    # Task Ingestion
    # -------------------------------------------------------------------------
    def submit_task(
        self,
        task_id: str,
        pickup_pose: Pose2D,
        dropoff_pose: Pose2D,
        priority: int = TaskPriority.PRIORITY_LOW,
        created_at: float = 0.0,
    ) -> Task:
        """Submit a new transport task to the queue."""
        task = Task(
            task_id=task_id,
            pickup_pose=pickup_pose,
            dropoff_pose=dropoff_pose,
            priority=priority,
            created_at=created_at,
            status=TaskStatus.QUEUED,
        )
        self.queue.enqueue(task)
        return task

    # -------------------------------------------------------------------------
    # Telemetry and Event Handlers
    # -------------------------------------------------------------------------
    @staticmethod
    def check_status_session(robot: RobotRecord, publisher_session_id: Optional[str]) -> bool:
        """Latch a session change before status can affect ownership."""
        if not robot.session_blocked and (
            publisher_session_id is not None
            and robot.session_id is not None
            and robot.session_id != publisher_session_id
        ):
            robot.session_blocked = True
            logger.error(
                "Robot %s publisher_session_id changed (%s -> %s). Robot transitioned to SESSION_BLOCKED.",
                robot.robot_id, robot.session_id, publisher_session_id,
            )
        return not robot.session_blocked

    def handle_robot_status(
        self,
        robot_id: str,
        state: int,
        current_phase: int,
        is_loaded: bool,
        pose: Optional[Pose2D],
        battery_soc_percent: float,
        battery_energy_wh: float,
        current_epoch: int,
        current_task_id: Optional[str],
        timestamp_sec: float,
        publisher_session_id: Optional[str] = None,
        source_status_ns: int = 0,
        pose_sample_ns: int = 0,
        pose_valid_until: Optional[float] = None,
        battery_sample_ns: int = 0,
        battery_valid_until: float = 0.0,
        dock_station_id: str = "",
        charging_station_id: str = "",
        physical_pose: Optional[Pose2D] = None,
        physical_sample_ns: int = 0,
        physical_valid_until: float = 0.0,
    ) -> Optional[RobotRecord]:
        """Process incoming 5 Hz RobotStatus message.
        
        Strictly preserves the Robot Executor as the single authority of physical state.
        Also checks physical departure from stations and marks BLOCKED if robot entered ERROR.
        """
        robot = self.tracker.get_robot(robot_id)
        if robot is None or not self.check_status_session(robot, publisher_session_id):
            return robot

        if not isinstance(pose, Pose2D) or not pose.has_finite_coordinates():
            pose = None

        dock = self.reservations.get_station(dock_station_id)
        if (dock is None or dock.station_type != StationType.CHARGING or not dock.has_owner(robot_id)
                or dock.state not in (ReservationState.OCCUPIED, ReservationState.RELEASING)):
            dock_station_id = ""
        if charging_station_id and charging_station_id != dock_station_id:
            charging_station_id = ""
            battery_valid_until = 0.0
        robot.dock_station_id = dock_station_id
        self.tracker.update_robot_status(
            robot_id=robot_id,
            state=state,
            current_phase=current_phase,
            is_loaded=is_loaded,
            pose=pose,
            battery_soc_percent=battery_soc_percent,
            battery_energy_wh=battery_energy_wh,
            current_epoch=current_epoch,
            current_task_id=current_task_id,
            timestamp_sec=timestamp_sec,
            battery_sample_ns=battery_sample_ns,
            battery_valid_until=battery_valid_until,
            charging_station_id=charging_station_id,
        )
        if robot.session_id is None:
            robot.session_id = publisher_session_id

        # Route planning may reuse a fresh sample repeated by RobotStatus.
        robot.route_pose_valid_until = 0.0
        if pose is not None:
            robot.route_pose_valid_until = (
                timestamp_sec + ROBOT_STATUS_STALE_TIMEOUT_SEC
                if pose_valid_until is None else pose_valid_until
            )

        # A newer heartbeat cannot renew a repeated measurement or retain old proof.
        robot.station_pose_valid_until = 0.0
        if (pose is not None and publisher_session_id and pose_valid_until
                and pose_sample_ns > robot.last_pose_sample_ns):
            robot.last_pose_sample_ns = pose_sample_ns
            robot.station_pose_valid_until = pose_valid_until

        # Check departure from any station robot was occupying/releasing
        for station in self.reservations.stations_owned_by(robot_id):
            if state == RobotState.STATE_ERROR:
                # Robot errored at station -> mark resource BLOCKED (C3-DEC §2.2)
                self.reservations.mark_blocked(
                    station.station_id, robot_id, session_id=robot.session_id,
                    error_status_ns=source_status_ns if publisher_session_id else 0,
                )
            elif (station.has_owner(robot_id)
                  and station.state in (ReservationState.RELEASING, ReservationState.OCCUPIED)
                  and pose is not None
                  and (pose_valid_until is None or robot.station_pose_valid_until)
                  and (not station.departure_after_ns or pose_sample_ns > station.departure_after_ns)):
                if station.station_type == StationType.CHARGING and station.departure_after_ns:
                    if (physical_sample_ns <= station.departure_after_ns
                            or not timestamp_sec <= physical_valid_until
                            or not station.is_physically_departed(physical_pose)):
                        continue
                self.reservations.update_physical_departure(station.station_id, pose)

        return robot

    def handle_action_feedback(
        self,
        robot_id: str,
        task_id: str,
        current_phase: int,
        assignment_epoch: int,
        goal_uuid: str,
    ) -> bool:
        """Validate and handle action feedback.
        
        Discards stale or mismatched feedback based on (task_id, epoch, goal_uuid).
        """
        robot = self.tracker.get_robot(robot_id)
        if robot is None:
            return False

        # Strictly validate assignment identity
        if (
            robot.current_task_id != task_id
            or robot.current_epoch != assignment_epoch
            or robot.active_goal_uuid != goal_uuid
        ):
            # Mismatched or stale feedback -> ignore
            return False

        task = self._active_tasks.get(task_id)
        if task is not None and task.status == TaskStatus.ASSIGNED:
            task.status = TaskStatus.EXECUTING

        return True

    def handle_action_result(
        self,
        robot_id: str,
        task_id: str,
        result_status: int,
        completed_epoch: int,
        goal_uuid: str,
        error_reason: str = "",
    ) -> Tuple[bool, Optional[Task]]:
        """Validate and handle terminal action result from Robot Executor.
        
        Strictly filters out-of-order or stale results (C3-DEC §2.3 / DOC-ARCH Sec 6).
        Returns (accepted, task).
        """
        robot = self.tracker.get_robot(robot_id)
        if robot is None:
            return False, None

        # Strictly match (task_id, completed_epoch, goal_uuid)
        if (
            type(completed_epoch) is not int
            or robot.current_task_id != task_id
            or robot.current_epoch != completed_epoch
            or robot.active_goal_uuid != goal_uuid
        ):
            # Outdated or duplicate result -> ignore (idempotency & deduplication)
            return False, None

        task = self._active_tasks.pop(task_id, None)
        self._active_tasks_by_robot.pop(robot_id, None)

        if task is None:
            return False, None

        if result_status == TaskResultStatus.STATUS_SUCCEEDED:
            task.status = TaskStatus.COMPLETED
            self._completed_tasks[task_id] = task
            # Clear robot active goal
            robot.active_goal_uuid = None
            robot.current_task_id = None
            if self.station_dispatch is not None:
                self.station_dispatch.park_due.add(robot_id)
            return True, task

        elif result_status == TaskResultStatus.STATUS_PREEMPTED:
            # Safe Preemption Handshake Completion:
            # 1. Increment victim task preemption_count
            task.preemption_count += 1
            task.status = TaskStatus.PREEMPTED
            # 2. Requeue victim with original created_at (Karar 08 T09)
            self.queue.requeue_preempted(task)

            # 3. Clear robot active goal
            robot.active_goal_uuid = None
            robot.current_task_id = None

            # The terminal result closes ownership. A scheduling tick must
            # evaluate the waiting task against current RobotStatus and routes.
            pending_high = self._pending_preemption_assignments.pop(robot_id, None)
            if pending_high is not None:
                self.queue.enqueue(pending_high)

            return True, task

        elif result_status == TaskResultStatus.STATUS_FAILED:
            # Strict Policy (P14, C3-DEC §2): No automatic retry or reassignment
            task.status = TaskStatus.FAILED
            self._failed_tasks[task_id] = task
            robot.active_goal_uuid = None
            robot.current_task_id = None

            # Mark occupied station BLOCKED if any
            for station in self.reservations.stations_owned_by(robot_id):
                self.reservations.mark_blocked(
                    station.station_id, robot_id, session_id=robot.session_id,
                    # A result can precede ERROR telemetry. It cannot establish the recovery fence.
                    error_status_ns=None if robot.state == RobotState.STATE_ERROR else 0,
                )

            return True, task

        return False, None

    # -------------------------------------------------------------------------
    # Scheduling Cycle
    # -------------------------------------------------------------------------
    def schedule_tick(
        self,
        current_time: float,
        station_lookup=None,
    ) -> List[Tuple[str, Assignment]]:
        """Run one scheduling evaluation pass across the queued tasks.
        
        Returns list of newly dispatched assignments: [(robot_id, Assignment), ...]
        """
        new_assignments: List[Tuple[str, Assignment]] = []

        # Iterate through queued tasks in Priority / FIFO order
        for task in self.queue.iter_assignable_tasks():
            # Ineligible if under active review hold (C3.3.2-DEC-03)
            if self.has_review_hold(task.task_id):
                continue

            # 1. Look for available eligible IDLE or returning robots
            idle_robots = self.tracker.get_eligible_idle_robots(current_time)
            # Filter out robots currently in preemption handshake
            idle_robots = [
                r for r in idle_robots
                if r.robot_id not in self._pending_preemption_assignments
                and r.robot_id not in self._active_tasks_by_robot
                and (self.station_dispatch is None or self.station_dispatch.allows_transport(self, r))
            ]

            selection = self.scheduler.select_best_idle_robot(
                task=task,
                available_robots=[robot for robot in idle_robots if not robot.dock_station_id],
                current_time=current_time,
            )
            if selection is None and task.task_id not in self.scheduler.pending_route_tasks:
                selection = self.scheduler.select_best_idle_robot(
                    task=task,
                    available_robots=[robot for robot in idle_robots if robot.dock_station_id],
                    current_time=current_time,
                )

            if selection is not None:
                robot, eval_res = selection
                # Assign task to this idle robot!
                self.queue.remove(task.task_id)
                assignment = self._dispatch_assignment(robot, task, current_time)
                new_assignments.append((robot.robot_id, assignment))
                continue

            if self.station_dispatch is not None and self.station_dispatch.request_park_cancel(
                self, task, current_time,
            ):
                continue

            # 2. If task is HIGH priority and no IDLE robot was available:
            #    Attempt safe preemption of a running LOW/MEDIUM task
            if (task.priority == TaskPriority.PRIORITY_HIGH
                    and task.task_id not in self.scheduler.pending_route_tasks):
                active_robots = [
                    r for r in self.tracker.list_robots()
                    if r.robot_id in self._active_tasks_by_robot
                    and r.robot_id not in self._pending_preemption_assignments
                ]
                preemption = self.scheduler.select_preemption_candidate(
                    high_task=task,
                    active_robots=active_robots,
                    active_tasks_by_robot=self._active_tasks_by_robot,
                    current_time=current_time,
                )
                if preemption is not None:
                    # Initiate preemption!
                    # Remove HIGH task from queue and hold it in pending preemption
                    self.queue.remove(task.task_id)
                    self._pending_preemption_assignments[preemption.robot_id] = task
                    # Note: We do NOT assign the HIGH task immediately!
                    # Fleet Manager must await terminal PREEMPTED result before dispatching (DOC-ARCH Sec 6.2).
                    logger.info(f"Initiated safe preemption: {preemption.reason}")

            # 3. If cannot assign or preempt, skip to next task in work-conserving FIFO

        if self.station_dispatch is not None:
            self.station_dispatch.schedule(self, current_time, station_lookup)
        return new_assignments

    # -------------------------------------------------------------------------
    # Internal Helpers
    # -------------------------------------------------------------------------
    def _dispatch_assignment(
        self,
        robot: RobotRecord,
        task: Task,
        current_time: float,
    ) -> Assignment:
        """Assign task to robot with incremented monotonic epoch and new goal UUID."""
        # Check if robot was at a station and initiate release
        for station in self.reservations.stations_owned_by(robot.robot_id):
            if station.state in (ReservationState.RESERVED, ReservationState.OCCUPIED):
                self.reservations.initiate_release(station.station_id, robot.robot_id)

        # Increment monotonic assignment epoch
        robot.current_epoch += 1
        new_uuid = str(uuid.uuid4())

        robot.current_task_id = task.task_id
        robot.active_goal_uuid = new_uuid
        robot.state = RobotState.STATE_EXECUTING_TASK

        task.assigned_robot_id = robot.robot_id
        task.assignment_epoch = robot.current_epoch
        task.goal_uuid = new_uuid
        task.status = TaskStatus.ASSIGNED

        self._active_tasks[task.task_id] = task
        self._active_tasks_by_robot[robot.robot_id] = task

        return Assignment(
            task_id=task.task_id,
            robot_id=robot.robot_id,
            assignment_epoch=robot.current_epoch,
            goal_uuid=new_uuid,
            pickup_pose=task.pickup_pose,
            dropoff_pose=task.dropoff_pose,
            priority=task.priority,
            assigned_at=current_time,
        )
