"""Robot fleet telemetry tracking and freshness monitor.

Adheres strictly to:
- C3-DEC-01: RobotStatus 2.0s stale threshold and immediate exclusion from assignment.
- C3-DEC-02: Communication loss monitoring without automatic FAILED/ERROR.
- Executor physical state authority: Fleet Manager holds an updated replica.
"""

from math import isclose, isfinite
from typing import Dict, List, Optional, Tuple

from .constants import (
    BATTERY_TELEMETRY_TIMEOUT_SEC,
    COMMUNICATION_ALERT_SEC,
    COMMUNICATION_WARNING_SEC,
    ROBOT_STATUS_STALE_TIMEOUT_SEC,
    RobotState,
)
from .models import Pose2D, RobotBatterySpecs, RobotRecord


class FleetTracker:
    """Tracks robot status telemetry and maintains the fleet operational registry."""

    def __init__(self) -> None:
        self._robots: Dict[str, RobotRecord] = {}

    def register_robot(
        self,
        robot_id: str,
        specs: Optional[RobotBatterySpecs] = None,
        initial_pose: Optional[Pose2D] = None,
        *,
        requires_battery_telemetry: bool = False,
    ) -> RobotRecord:
        """Register a robot from fleet configuration."""
        if robot_id in self._robots:
            raise ValueError(f"Robot {robot_id} already registered")

        record = RobotRecord(
            robot_id=robot_id,
            specs=specs or RobotBatterySpecs(),
            pose=initial_pose or Pose2D(),
            state=RobotState.STATE_IDLE,
            idle_start_timestamp=0.0,
            requires_battery_telemetry=requires_battery_telemetry,
        )
        if requires_battery_telemetry:
            record.battery_soc_percent = record.battery_energy_wh = 0.0
        self._robots[robot_id] = record
        return record

    def get_robot(self, robot_id: str) -> Optional[RobotRecord]:
        """Lookup robot record by id."""
        return self._robots.get(robot_id)

    def list_robots(self) -> List[RobotRecord]:
        """List all registered robot records."""
        return list(self._robots.values())

    def update_robot_status(
        self,
        robot_id: str,
        state: int,
        current_phase: int,
        is_loaded: bool,
        pose: Optional[Pose2D],
        battery_soc_percent: float,
        battery_energy_wh: float,
        current_epoch: int,
        current_task_id: Optional[str],
        timestamp_sec: float,
        battery_sample_ns: int = 0,
        battery_valid_until: float = 0.0,
        charging_station_id: str = "",
    ) -> Optional[RobotRecord]:
        """Update robot record from incoming RobotStatus message (5 Hz).
        
        The physical state authority belongs to Robot Executor.
        Fleet Manager updates its replica and tracks idle timestamps.
        """
        robot = self._robots.get(robot_id)
        if robot is None:
            return None

        # Track idle transition for tie-breaking
        if state == RobotState.STATE_IDLE and robot.state != RobotState.STATE_IDLE:
            robot.idle_start_timestamp = timestamp_sec
        elif state != RobotState.STATE_IDLE:
            robot.idle_start_timestamp = 0.0

        robot.state = state
        robot.current_phase = current_phase
        robot.is_loaded = is_loaded
        if pose is not None:
            robot.pose = pose
        self._update_battery(robot, battery_soc_percent, battery_energy_wh,
                             battery_sample_ns, battery_valid_until, timestamp_sec, charging_station_id)
        robot.current_epoch = current_epoch
        robot.current_task_id = current_task_id
        robot.last_status_received_at = timestamp_sec

        # Initial status verification for clean startup (C3.3.2-DEC-04)
        if not robot.session_blocked and state == RobotState.STATE_IDLE and not is_loaded and (not current_task_id or current_task_id == ""):
            robot.initial_status_verified = True

        return robot

    @staticmethod
    def _update_battery(robot, soc, energy, sample_ns, valid_until, received_at, charging_station_id):
        if not robot.requires_battery_telemetry:
            robot.battery_soc_percent = soc
            robot.battery_energy_wh = energy
            return

        capacity = robot.specs.usable_capacity_wh
        if (not 0 < sample_ns or sample_ns < robot.battery_sample_ns
                or not isfinite(valid_until) or not received_at <= valid_until <= received_at + BATTERY_TELEMETRY_TIMEOUT_SEC
                or not 0 <= energy <= capacity or not 0 <= soc <= 100
                or not isclose(soc, 100.0 * (energy / capacity), rel_tol=0.0, abs_tol=5e-6)
                or (robot.battery_sample_ns and energy > robot.battery_energy_wh
                    and not (charging_station_id or robot.charging_station_id))):
            robot.battery_valid_until = 0.0
        elif sample_ns == robot.battery_sample_ns:
            if (energy, soc, charging_station_id) != (
                robot.battery_energy_wh, robot.battery_soc_percent, robot.charging_station_id,
            ):
                robot.battery_valid_until = 0.0
            else:
                robot.battery_valid_until = min(robot.battery_valid_until, valid_until)
        else:
            robot.battery_soc_percent = soc
            robot.battery_energy_wh = energy
            robot.battery_sample_ns = sample_ns
            robot.battery_valid_until = valid_until
            robot.charging_station_id = charging_station_id

    def is_stale(
        self,
        robot_id: str,
        current_time: float,
        threshold: float = ROBOT_STATUS_STALE_TIMEOUT_SEC,
    ) -> bool:
        """Return True if robot telemetry has not been updated within threshold."""
        robot = self._robots.get(robot_id)
        if robot is None:
            return True
        return robot.is_stale(current_time, threshold=threshold)

    def get_eligible_idle_robots(self, current_time: float) -> List[RobotRecord]:
        """Return idle robots that are fresh and ready for task evaluation.
        
        STRICT CONTRACT (C3-DEC-01):
        Robots not updated within 2.0 seconds are STALE and must be excluded.
        """
        eligible = []
        for robot in self._robots.values():
            if robot.is_eligible_for_new_assignment(current_time):
                eligible.append(robot)
        return eligible

    def check_communication_health(
        self,
        current_time: float,
    ) -> List[Tuple[str, str, float]]:
        """Check communication delays for all robots.
        
        Returns list of (robot_id, severity, elapsed_time_sec).
        Severity can be:
        - "WARNING" (>= 5.0s, C3-DEC-02)
        - "ALERT" (>= 10.0s, C3-DEC-02 notice)
        
        STRICT CONTRACT (C3-DEC-02):
        Communication loss at 10.0s DOES NOT automatically fail the active task
        or mark the robot as ERROR.
        """
        notices = []
        for r_id, robot in self._robots.items():
            if robot.last_status_received_at <= 0.0:
                continue
            dt = current_time - robot.last_status_received_at
            if dt >= COMMUNICATION_ALERT_SEC:
                notices.append((r_id, "ALERT", dt))
            elif dt >= COMMUNICATION_WARNING_SEC:
                notices.append((r_id, "WARNING", dt))
        return notices
