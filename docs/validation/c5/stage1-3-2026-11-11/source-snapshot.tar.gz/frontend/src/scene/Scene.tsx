import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { memo, useLayoutEffect, useRef } from 'react'
import { Box3, Group, PerspectiveCamera, Quaternion, Ray, Vector3, type Object3D } from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import { Burger, burgerSize, frontMarkerX } from './Burger'
import {
  followDistance, followTarget, maxCameraDistance, minCameraDistance, startOffset, targetHeight, topAngle,
  type CameraCommand,
} from './camera'
import { blendMs, blendPose, toScene } from './coordinates'
import { frameWarehouse, warehouseCorners } from './framing'
import { markerDiameter } from './marker'
import { RouteLayers } from './RouteLayers'
import type { RouteOptions } from './routes'
import type { Pose } from './telemetry'
import type { SceneFeed } from './sceneFeed'
import { GridWarehouse } from './GridWarehouse'
import { crossesRack } from './gridClearance'
import type { GridLayout } from './gridLayout'
import { WarehouseEnvironment } from './Warehouse'
import { OperationMarkers } from './OperationMarkers'
import { Costmap, type CostmapGrid } from './Costmap'
import { calloutCandidates, hitsArea, insideFloor, projectedArea, screenPoint, type ScreenRect } from './calloutPlacement'
import type { OperationLabel, OperationPoint } from './operationPoints'

type SceneProps = {
  layout?: GridLayout
  costmap?: CostmapGrid
  feed: SceneFeed
  command: CameraCommand
  lowQuality: boolean
  labels: Map<string, HTMLSpanElement>
  markers: Map<string, HTMLButtonElement>
  points: OperationPoint[]
  labelPoints: OperationLabel[]
  pointLabels: Map<string, HTMLSpanElement>
  leaders: Map<string, SVGLineElement>
  robotIds: string[]
  selected?: string
  onSelect: (id: string) => void
  trace: boolean
  routes: RouteOptions
}

const polarLimit = Math.PI / 2 - 0.045
const fov = 42
const calloutOverview = [0.40, 1.50, 0.94] as const

type LabelPlacement = { label: HTMLSpanElement; candidates: ScreenRect[]; taskAnchor?: [number, number]; scale: number;
  leader?: { line: SVGLineElement; target: [number, number] } }

function overlaps(a: ScreenRect, b: ScreenRect) {
  return a.left < b.right + 4 && a.right + 4 > b.left && a.top < b.bottom + 3 && a.bottom + 3 > b.top
}

function Vehicles({ layout: grid, feed, command, lowQuality, labels, markers, points, labelPoints, pointLabels, leaders, robotIds, selected, onSelect, trace, routes }: SceneProps) {
  const models = useRef(new Map<string, Group>()).current
  const orbit = useRef<OrbitControls | null>(null)
  const lastPose = useRef<Pose>(undefined)
  const tracedPoses = useRef(new WeakSet<Pose>()).current
  const previousSelection = useRef<string>(undefined)
  const fitted = useRef(false)
  const cameraCommand = useRef(command)
  const warehouseLayout = useRef<Group>(undefined)
  const warehouseFrame = useRef<Vector3[]>(undefined)
  const cutaways = useRef<{ object: Object3D; bounds: Box3 }[]>([])
  const rackConflicts = useRef(new WeakMap<object, Set<string>>())
  const aspect = useRef(0)
  const preset = useRef(true)
  const transitioning = useRef(false)
  const goalTarget = useRef(new Vector3(0, targetHeight, 0))
  const goalOffset = useRef(new Vector3(...startOffset))
  const scratch = useRef({
    shift: new Vector3(), destination: new Vector3(), screen: new Vector3(),
    front: new Vector3(), rotation: new Quaternion(), bounds: new Box3(), extent: new Vector3(),
    ray: new Ray(), body: new Vector3(), obstruction: new Vector3(),
  })
  const filteredId = routes.selectedOnly ? selected : undefined
  const { camera, gl, invalidate } = useThree()

  useLayoutEffect(() => {
    const controls = new OrbitControls(camera, gl.domElement)
    controls.target.set(0, targetHeight, 0)
    controls.minDistance = minCameraDistance
    controls.maxDistance = maxCameraDistance
    controls.maxPolarAngle = polarLimit
    controls.enableDamping = true
    controls.dampingFactor = 0.16
    controls.update()
    let interacting = false
    const startInteraction = () => { interacting = true }
    const endInteraction = () => { interacting = false }
    const requestFrame = () => {
      if (interacting) preset.current = false
      invalidate()
    }
    controls.addEventListener('change', requestFrame)
    controls.addEventListener('start', startInteraction)
    controls.addEventListener('end', endInteraction)
    orbit.current = controls
    const unsubscribe = feed.subscribe(invalidate)
    invalidate()
    return () => {
      unsubscribe()
      controls.removeEventListener('change', requestFrame)
      controls.removeEventListener('start', startInteraction)
      controls.removeEventListener('end', endInteraction)
      controls.dispose()
      orbit.current = null
    }
  }, [camera, gl, feed, invalidate])

  useLayoutEffect(() => { invalidate() }, [command, lowQuality, selected, routes, points, invalidate])
  useLayoutEffect(() => { fitted.current = false }, [routes.selectedOnly, filteredId])

  useFrame(({ size, scene }, delta) => {
    const controls = orbit.current
    if (!controls) return

    const { robots } = feed.read()
    const now = performance.now()
    const { shift, destination, screen, front, rotation, bounds, extent, ray, body, obstruction } = scratch.current
    const nextMode = command.mode
    const nextAspect = size.width / size.height
    if (!Number.isFinite(nextAspect) || nextAspect <= 0) return
    const resized = aspect.current !== nextAspect
    const firstFrame = aspect.current === 0
    aspect.current = nextAspect
    const environment = scene.getObjectByName('warehouse-environment')!
    const layout = (environment.getObjectByName('warehouse-grid') ??
      environment.getObjectByName('warehouse-layout')) as Group | undefined
    const layoutChanged = warehouseLayout.current !== layout
    if (!warehouseFrame.current || layoutChanged) {
      warehouseLayout.current = layout
      rackConflicts.current = new WeakMap()
      warehouseFrame.current = warehouseCorners(environment)
      cutaways.current = []
      const decorBounds: { name: string; min: number[]; max: number[] }[] = []
      environment.traverse(object => {
        if (!object.userData.cutaway) return
        const box = new Box3().setFromObject(object)
        if (trace) decorBounds.push({ name: object.name, min: box.min.toArray(), max: box.max.toArray() })
        // Expand the sightline test by the Burger envelope so partial cover also triggers a cutaway.
        box.expandByScalar(Math.hypot(burgerSize.length, burgerSize.width, burgerSize.height) / 2)
        cutaways.current.push({ object, bounds: box })
      })
      if (trace) gl.domElement.dispatchEvent(new CustomEvent('fleet-visualizer:warehouse-bounds', {
        bubbles: true, detail: warehouseFrame.current.map(corner => corner.toArray()),
      }))
      if (trace) gl.domElement.dispatchEvent(new CustomEvent('fleet-visualizer:decor-bounds', {
        bubbles: true, detail: { layout: grid ? 'grid' : layout ? 'glb' : 'schematic', boxes: decorBounds },
      }))
      if (trace) gl.domElement.dispatchEvent(new CustomEvent('fleet-visualizer:storage', {
        bubbles: true, detail: layout?.getObjectByName('warehouse-decor')?.userData.storageBounds ?? [],
      }))
    }
    if (resized && preset.current && nextMode === 'fit') fitted.current = false
    const oldCommand = cameraCommand.current
    const priorPose = lastPose.current
    const selectionChanged = selected !== previousSelection.current
    previousSelection.current = selected
    const target = selected ? robots.get(selected) : undefined
    const robot = selected ? models.get(selected) : undefined
    const { pose, previous, status } = target ?? {}
    let interpolating = false
    bounds.makeEmpty()
    for (const [id, root] of models) {
      const sample = robots.get(id)
      const measured = sample?.pose
      const displayed = measured && sample.previous
        ? blendPose(sample.previous, measured, now - measured.receivedAt) : measured
      root.visible = !!displayed && (!routes.selectedOnly || id === selected)
      if (!displayed || !root.visible) continue
      const [x, z, heading] = toScene(displayed)
      root.position.set(x, 0, z)
      root.rotation.y = heading
      bounds.expandByPoint(root.position)
      interpolating ||= displayed !== measured
    }
    lastPose.current = pose

    const changed = oldCommand !== command
    const warehouseMode = nextMode === 'free' || nextMode === 'top'
    const restoreWarehouse = changed && (nextMode === 'top' || command.reset !== oldCommand.reset ||
      (oldCommand.mode === 'top' && nextMode === 'free'))
    if (restoreWarehouse) preset.current = true

    if (changed) {
      cameraCommand.current = command
      goalTarget.current.copy(controls.target)
      goalOffset.current.copy(camera.position).sub(controls.target)
      if (nextMode === 'free' && !restoreWarehouse) preset.current = false
      if (nextMode === 'fit') {
        preset.current = true
        fitted.current = false
      }
      if (nextMode === 'follow' && goalOffset.current.length() > followDistance) goalOffset.current.setLength(followDistance)
      controls.minPolarAngle = 0
      controls.maxPolarAngle = Math.PI / 2
      controls.enableDamping = false
      controls.enabled = false
      transitioning.current = true
    }

    if (warehouseMode && (restoreWarehouse || ((resized || layoutChanged) && preset.current))) {
      frameWarehouse(warehouseFrame.current, fov, nextAspect, nextMode === 'top', goalTarget.current,
        goalOffset.current, grid?.zones.some(zone => zone.callout) ? calloutOverview : undefined)
      if (firstFrame || !transitioning.current) {
        controls.target.copy(goalTarget.current)
        camera.position.copy(goalTarget.current).add(goalOffset.current)
      }
    }

    if (nextMode === 'fit' && !fitted.current && !bounds.isEmpty()) {
      bounds.getCenter(goalTarget.current).setY(targetHeight)
      const radius = bounds.getSize(extent).length() / 2 + 0.55
      const vertical = (camera as PerspectiveCamera).fov * Math.PI / 360
      const horizontal = Math.atan(Math.tan(vertical) * size.width / size.height)
      const distance = radius / Math.sin(Math.min(vertical, horizontal))
      goalOffset.current.set(...startOffset).setLength(Math.min(maxCameraDistance, distance))
      controls.enableDamping = false
      controls.enabled = false
      transitioning.current = true
      fitted.current = true
    }

    if (nextMode === 'follow' && robot?.visible) {
      const [x, y, z] = followTarget(robot.position.x, robot.position.z)
      if (transitioning.current && !changed && !selectionChanged && previous) {
        // Keep the transition converging relative to a continuously moving target.
        shift.set(x, y, z).sub(goalTarget.current)
        controls.target.add(shift)
        camera.position.add(shift)
      }
      goalTarget.current.set(x, y, z)
      if (!transitioning.current && (selectionChanged || (pose !== priorPose && !previous && status === 'LIVE')) &&
          controls.target.distanceToSquared(goalTarget.current) > 0.0144) {
        goalOffset.current.copy(camera.position).sub(controls.target)
        if (goalOffset.current.length() > followDistance) goalOffset.current.setLength(followDistance)
        controls.enableDamping = false
        controls.enabled = false
        transitioning.current = true
      }
    }

    if (transitioning.current) {
      const fraction = 1 - Math.exp(-Math.min(delta, 0.05) * 14)
      destination.copy(goalTarget.current).add(goalOffset.current)
      controls.target.lerp(goalTarget.current, fraction)
      camera.position.lerp(destination, fraction)
      if (camera.position.distanceToSquared(destination) < 0.000025 &&
          controls.target.distanceToSquared(goalTarget.current) < 0.000025) {
        camera.position.copy(destination)
        controls.target.copy(goalTarget.current)
        controls.minPolarAngle = nextMode === 'top' ? topAngle : 0
        controls.maxPolarAngle = nextMode === 'top' ? topAngle : polarLimit
        controls.enableRotate = nextMode !== 'top'
        controls.enablePan = nextMode !== 'follow'
        controls.enableDamping = true
        controls.enabled = true
        transitioning.current = false
      }
    } else if (nextMode === 'follow' && robot?.visible) {
      shift.copy(goalTarget.current).sub(controls.target)
      camera.position.add(shift)
      controls.target.copy(goalTarget.current)
    }
    controls.update()
    camera.updateMatrixWorld()

    const hiddenRacks = new Set<string>()
    if (grid && !grid.approach_clearance_m) {
      const record = <T,>(samples: readonly T[], point: (sample: T) => readonly [number, number],
        starts?: (sample: T) => boolean) => {
        let hits = rackConflicts.current.get(samples)
        if (!hits) {
          hits = new Set()
          for (let i = 0; i < samples.length; i++) {
            const [x, y] = point(samples[i])
            const [a, b] = i && !starts?.(samples[i]) ? point(samples[i - 1]) : [x, y]
            for (const rack of grid.racks) {
              if (!hits.has(rack.id) && crossesRack(rack.bounds, a, b, x, y)) hits.add(rack.id)
            }
          }
          rackConflicts.current.set(samples, hits)
        }
        for (const id of hits) hiddenRacks.add(id)
      }
      for (const sample of robots.values()) {
        if (sample.pose) {
          const { x, y } = sample.pose
          for (const rack of grid.racks) if (crossesRack(rack.bounds, x, y, x, y)) hiddenRacks.add(rack.id)
        }
        if (sample.path?.points) record(sample.path.points, point => point)
        if (sample.trail) record(sample.trail, ({ pose }) => [pose.x, pose.y], point => point.start)
      }
    }
    for (const { object } of cutaways.current) {
      const { side, edge } = object.userData
      const nearWall = (side === 'north' && -camera.position.z > edge) ||
        (side === 'south' && -camera.position.z < edge) ||
        (side === 'east' && camera.position.x > edge) || (side === 'west' && camera.position.x < edge)
      object.visible = !nearWall && !hiddenRacks.has(object.name)
    }
    for (const root of models.values()) {
      if (!root.visible) continue
      body.copy(root.position).addScaledVector(camera.up, burgerSize.height / 2)
      const distance = ray.direction.copy(body).sub(camera.position).length()
      ray.direction.normalize()
      ray.origin.copy(camera.position)
      for (const { object, bounds } of cutaways.current) {
        if (object.visible && (bounds.containsPoint(ray.origin) ||
            (ray.intersectBox(bounds, obstruction) && obstruction.distanceTo(ray.origin) < distance))) {
          object.visible = false
        }
      }
    }

    const placementAreas = grid && leaders.size ? {
      floor: projectedArea(grid.bounds, 0, camera, size.width, size.height),
      blocked: [
        ...grid.racks.map(item => projectedArea(item.bounds, item.height, camera, size.width, size.height)),
        ...(grid.example_tasks?.length ? [] : grid.zones.map(item => projectedArea(item.bounds, 0, camera, size.width, size.height))),
      ],
    } : undefined
    for (const line of leaders.values()) line.style.visibility = 'hidden'
    const placements: LabelPlacement[] = []
    const occupied: ScreenRect[] = []
    const radius = markerDiameter / 2
    const labelScale = (anchor: Vector3) => grid
      ? Math.max(.82, Math.min(1.15, 1.15 - camera.position.distanceTo(anchor) / 65)) : 1
    for (const [id, root] of models) {
      const label = labels.get(id)
      const marker = markers.get(id)
      if (!label || !marker) continue
      screen.copy(root.position).project(camera)
      if (!root.visible || Math.abs(screen.x) > 1 || Math.abs(screen.y) > 1 || Math.abs(screen.z) > 1) {
        marker.style.visibility = label.style.visibility = 'hidden'
        continue
      }

      const x = (screen.x + 1) / 2 * size.width
      const y = (1 - screen.y) / 2 * size.height
      const yaw = root.rotation.y
      front.copy(root.position)
      front.x += frontMarkerX * Math.cos(yaw)
      front.z -= frontMarkerX * Math.sin(yaw)
      front.project(camera)
      const heading = Math.atan2((screen.y - front.y) * size.height, (front.x - screen.x) * size.width)
      marker.style.visibility = 'visible'
      marker.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%)`
      marker.style.setProperty('--heading', `${heading}rad`)

      const scale = labelScale(root.position)
      const left = x - label.offsetWidth * scale / 2
      const right = x + label.offsetWidth * scale / 2
      const height = label.offsetHeight * scale
      front.copy(root.position)
      front.y += burgerSize.height
      front.project(camera)
      const bodyTop = (1 - front.y) / 2 * size.height
      const bodyRadius = grid ? Math.max(radius, Math.abs(y - bodyTop) * 1.45) : radius
      occupied.push({ left: x - bodyRadius, right: x + bodyRadius, top: grid ? Math.min(y - radius, bodyTop) : y - radius,
        bottom: y + radius })
      const above = Math.min(y - radius, bodyTop) - 4
      const below = y + radius + 4
      const placement = { label, scale, candidates: [{ left, right, top: above - height, bottom: above }] }
      if (id === selected) {
        placement.candidates.push({ left, right, top: below, bottom: below + height })
        placements.unshift(placement)
      } else placements.push(placement)
    }
    for (const point of labelPoints) {
      const label = pointLabels.get(point.key)
      if (!label) continue
      screen.fromArray(point.position).project(camera)
      if (Math.abs(screen.x) > 1 || Math.abs(screen.y) > 1 || Math.abs(screen.z) > 1) {
        label.style.visibility = 'hidden'
        continue
      }
      const x = (screen.x + 1) / 2 * size.width
      const y = (1 - screen.y) / 2 * size.height
      const distance = camera.position.distanceTo(front.fromArray(point.position))
      if ((point.lod === 'near' && distance >= 16) || (point.lod === 'far' && distance < 16)) {
        label.style.visibility = 'hidden'
        continue
      }
      if (point.leader) label.toggleAttribute('data-detailed', distance < 16)
      const scale = labelScale(front)
      const width = label.offsetWidth * scale
      const height = label.offsetHeight * scale
      const gap = 18
      const task = point.kind === 'pickup' || point.kind === 'dropoff'
      const candidates: ScreenRect[] = [
        { left: x + gap, right: x + gap + width, top: y - height / 2, bottom: y + height / 2 },
        { left: x - gap - width, right: x - gap, top: y - height / 2, bottom: y + height / 2 },
        { left: x - width / 2, right: x + width / 2, top: y + gap, bottom: y + gap + height },
        { left: x - width / 2, right: x + width / 2, top: y - gap - height, bottom: y - gap },
        { left: x + gap, right: x + gap + width, top: y + gap / 2, bottom: y + gap / 2 + height },
        { left: x - gap - width, right: x - gap, top: y + gap / 2, bottom: y + gap / 2 + height },
        { left: x + gap, right: x + gap + width, top: y - gap / 2 - height, bottom: y - gap / 2 },
        { left: x - gap - width, right: x - gap, top: y - gap / 2 - height, bottom: y - gap / 2 },
      ]
      const line = leaders.get(point.key)
      if (point.leader && line) {
        const target = screenPoint(front.fromArray(point.leader), camera, size.width, size.height)
        placements.push({ label, scale, candidates: calloutCandidates(x, y, width, height), leader: { line, target } })
        continue
      }
      if (point.groupText) {
        // Try the group's own floor anchor and its vertical offsets before moving sideways.
        candidates.unshift({ left: x - width / 2, right: x + width / 2,
          top: y - height / 2, bottom: y + height / 2 }, ...candidates.splice(2, 2))
      }
      placements.push({ label, scale, taskAnchor: task ? [x, y] : undefined, candidates })
    }
    let visibleTask: [number, number] | undefined
    for (const { label, candidates, taskAnchor, scale, leader } of placements) {
      // When two task anchors almost coincide, a distant second label would
      // read as a different location. Both ground symbols remain visible.
      const sharesAnchor = taskAnchor && visibleTask &&
        Math.hypot(taskAnchor[0] - visibleTask[0], taskAnchor[1] - visibleTask[1]) < 12
      const slot = !sharesAnchor && candidates.find(rect => rect.left >= 3 && rect.right <= size.width - 3 &&
        rect.top >= 3 && rect.bottom <= size.height - 3 && !occupied.some(other => overlaps(rect, other)) &&
        (!leader || (placementAreas && insideFloor(rect, placementAreas.floor) &&
          !placementAreas.blocked.some(area => hitsArea(rect, area)))))
      label.style.visibility = slot ? 'visible' : 'hidden'
      if (!slot) continue
      label.style.transformOrigin = "top left"
      label.style.transform = `translate(${slot.left}px, ${slot.top}px) scale(${scale})`
      if (leader) {
        const [x, y] = leader.target
        const { line } = leader
        line.setAttribute('x1', String(Math.max(slot.left, Math.min(slot.right, x))))
        line.setAttribute('y1', String(Math.max(slot.top, Math.min(slot.bottom, y))))
        line.setAttribute('x2', String(x))
        line.setAttribute('y2', String(y))
        line.style.visibility = 'visible'
      }
      occupied.push(slot)
      if (taskAnchor) visibleTask = taskAnchor
    }
    if (transitioning.current || interpolating) invalidate()

    if (trace) {
      gl.render(scene, camera)
      const roots = []
      for (const [id, root] of models) {
        const sample = robots.get(id)
        const measured = sample?.pose
        const blending = measured && sample.previous && now - measured.receivedAt < blendMs
        const blend = blending && sample.previous ? {
          stream_id: measured.stream_id, epoch: measured.epoch, from: sample.previous.stamp_ns, to: measured.stamp_ns,
          fraction: Math.max(0, (now - measured.receivedAt) / blendMs),
        } : undefined
        screen.copy(root.position).addScaledVector(camera.up, burgerSize.height / 2).project(camera)
        roots.push({ robot_id: id, pose: root.position.toArray(), yaw: root.rotation.y, visible: root.visible,
          status: sample?.status, blend, screen: [(screen.x + 1) / 2, (1 - screen.y) / 2] })
        if (!root.visible || !measured || blending || tracedPoses.has(measured)) continue
        tracedPoses.add(measured)
        const marker = root.getObjectByName('robot-front-marker')!
        front.set(0, 1, 0).applyQuaternion(marker.getWorldQuaternion(rotation))
        gl.domElement.dispatchEvent(new CustomEvent('fleet-visualizer:rendered', {
          bubbles: true,
          detail: { robot_id: id, stamp_ns: measured.stamp_ns, stream_id: measured.stream_id,
            epoch: measured.epoch, x: root.position.x, z: root.position.z,
            heading_x: front.x, heading_z: front.z, receive_to_frame_ms: now - measured.receivedAt },
        }))
      }
      const selectedRoot = roots.find(root => root.robot_id === selected)
      gl.domElement.dispatchEvent(new CustomEvent('fleet-visualizer:frame', {
        bubbles: true,
        detail: {
          at: now, interpolating: !!selectedRoot?.blend, visible: !!selectedRoot?.visible,
          blend: selectedRoot?.blend, pose: selectedRoot?.pose ?? [0, 0, 0], yaw: selectedRoot?.yaw ?? 0,
          robots: roots, selected, mode: nextMode, reset: command.reset, transitioning: transitioning.current,
          target: controls.target.toArray(), camera: camera.position.toArray(),
          calls: gl.info.render.calls, triangles: gl.info.render.triangles,
          geometries: gl.info.memory.geometries, textures: gl.info.memory.textures,
          dpr: gl.getPixelRatio(), warehouse: grid ? 'grid' : layout ? 'glb' : 'schematic',
          routeHiddenRacks: [...hiddenRacks],
          cutaway: cutaways.current.filter(({ object }) => !object.visible).map(({ object }) => object.name),
          points: points.map(point => {
            const root = scene.getObjectByName(point.key)!
            const dock = root.getObjectByName('charging-unit')
            const pad = root.getObjectByName('operation-pad')!
            const symbol = root.getObjectByName('operation-symbol')
            return { ...point,
              padSize: bounds.setFromObject(pad, true).getSize(extent).toArray(),
              padPosition: pad.getWorldPosition(screen).toArray(),
              symbol: !!symbol,
              position: root.getWorldPosition(screen).toArray(), yaw: root.rotation.y,
              dockPosition: dock?.getWorldPosition(screen).toArray(),
              dockBounds: dock ? (() => {
                bounds.setFromObject(dock)
                return { min: bounds.min.toArray(), max: bounds.max.toArray() }
              })() : undefined }
          }),
        },
      }))
    }
  }, trace ? 1 : 0)

  return robotIds.map(id => <group key={id}
    ref={root => { if (root) models.set(id, root); else models.delete(id) }}
    name={`robot-ros-pose:${id}`} visible={false}
    onClick={event => {
      if (event.eventObject.visible && event.delta <= 4) {
        event.stopPropagation()
        onSelect(id)
      }
    }}>
    <Burger softShadows={!lowQuality} />
    {id === selected && <mesh name="selected-robot-halo" rotation-x={-Math.PI / 2} position-y={.018}>
      <ringGeometry args={[.228, .25, 32]} />
      <meshBasicMaterial color="#0e5d55" transparent opacity={.56} depthWrite={false} />
    </mesh>}
  </group>)
}

const initialCamera = { position: [8, 11, 10] as [number, number, number], fov, near: 0.035, far: 240 }

export default memo(function Scene(props: SceneProps) {
  return <Canvas frameloop="demand" dpr={props.lowQuality ? 1 : [1, 1.5]} camera={initialCamera}
    fallback={<p className="scene-message">3D görünüm için WebGL desteği gerekiyor.</p>}>
    <color attach="background" args={['#edf2f1']} />
    <hemisphereLight args={['#ffffff', '#c2cbd1', 1.65]} />
    <directionalLight position={[2, 8, -3]} intensity={1.95} color="#fff6e9" />
    <directionalLight position={[-6, 3, 5]} intensity={0.42} color="#e0ecfc" />
    {props.layout ? <GridWarehouse layout={props.layout} softShadows={!props.lowQuality} />
      : <WarehouseEnvironment softShadows={!props.lowQuality} />}
    <OperationMarkers points={props.points} grid={!!props.layout} dockApproach={props.layout?.dock_approach_m} />
    {props.costmap && <Costmap grid={props.costmap} />}
    {props.robotIds.map((id, index) => <RouteLayers key={id} feed={props.feed} id={id} colorIndex={index}
      selected={id === props.selected} options={props.routes} trace={props.trace} />)}
    <Vehicles {...props} />
  </Canvas>
})
