"""Real ROS 2 Humble integration tests for Fleet Manager adapters.

Requires ROS 2 Humble runtime and fleet_interfaces installed (runs in docker).
Verifies:
- RobotStatus subscriber with status_seq and publisher_session_id
- ExecuteTask ActionClient with identical goal UUID, feedback, and completed_epoch matching
- ClearRobotError service call with expected_epoch
- Session change transition to SESSION_BLOCKED
"""

import asyncio
import os
import threading
import time
import uuid
import pytest

try:
    import rclpy
    from rclpy.action import ActionServer, CancelResponse, GoalResponse
    from rclpy.node import Node
    from rclpy.executors import SingleThreadedExecutor

    from fleet_interfaces.action import ExecuteTask
    from fleet_interfaces.msg import RobotStatus
    from fleet_interfaces.srv import ClearRobotError
    from geometry_msgs.msg import PoseStamped
    from unique_identifier_msgs.msg import UUID as RosUUID
    HAS_ROS2 = True
except ImportError:
    HAS_ROS2 = False

pytestmark = pytest.mark.skipif(not HAS_ROS2, reason="Requires ROS 2 Humble runtime and fleet_interfaces installed")

if HAS_ROS2:
    from backend.fleet_manager.adapters.action_client import ExecuteTaskActionClientBridge
    from backend.fleet_manager.adapters.outbox_sender import ROS2OutboxSender
    from backend.fleet_manager.adapters.ros2_adapter_node import FleetROS2Adapter
    from backend.fleet_manager.adapters.service_client import ClearRobotErrorServiceClient
    from backend.fleet_manager.adapters.status_subscriber import RobotStatusSubscriberBridge
    from backend.fleet_manager.domain.constants import RobotState, StationType, TaskPriority, TaskResultStatus
    from backend.fleet_manager.domain.fleet_manager_core import FleetManagerCore
    from backend.fleet_manager.domain.models import Pose2D
    from backend.fleet_manager.domain.scheduler import RouteDistanceProvider
    from backend.fleet_manager.event_loop import Event, FleetEventLoop, OutboxDispatcher
    from backend.fleet_manager.persistence.store import SQLiteStore

    class MockRoutes(RouteDistanceProvider):
        def get_path_distance(self, robot_id, start: Pose2D, goal: Pose2D):
            return 10.0


def test_ros2_status_subscription_and_session_blocked(tmp_path):
    """Verify real ROS 2 station recovery and session change detection."""
    rclpy.init()
    node = Node("test_fm_status_node")
    pub_node = Node("test_robot_publisher_node")

    db_path = str(tmp_path / "test_ros2_status.db")
    store = SQLiteStore(db_path)
    core = FleetManagerCore(MockRoutes(), Pose2D())
    core.register_robot("robot_1")
    core.register_station("dock", StationType.CHARGING, Pose2D())

    async def scenario():
        loop = FleetEventLoop(store, core)
        await loop.start()

        bridge = RobotStatusSubscriberBridge(
            consumer=loop,
            loop=asyncio.get_running_loop(),
            robot_id="robot_1",
            ros_clock_ns=lambda: node.get_clock().now().nanoseconds,
        )

        sub = node.create_subscription(
            RobotStatus,
            "/robot_1/robot_status",
            bridge.handle_status_msg,
            10,
        )

        pub = pub_node.create_publisher(RobotStatus, "/robot_1/robot_status", 10)

        # Background thread to spin pub_node and node
        executor = SingleThreadedExecutor()
        executor.add_node(node)
        executor.add_node(pub_node)

        spin_thread = threading.Thread(target=executor.spin, daemon=True)
        spin_thread.start()

        # Send initial status
        sess_1 = uuid.uuid4()
        msg1 = RobotStatus()
        msg1.robot_id = "robot_1"
        msg1.status_seq = 1
        msg1.publisher_session_id = RosUUID(uuid=list(sess_1.bytes))
        msg1.current_epoch = 0
        msg1.state = RobotState.STATE_IDLE
        msg1.current_phase = 0
        msg1.is_loaded = False
        msg1.pose.header.frame_id = "map"
        msg1.battery_soc_percent = 90.0
        msg1.battery_energy_wh = 90.0
        msg1.current_task_id = ""
        msg1.header.stamp = pub_node.get_clock().now().to_msg()

        pub.publish(msg1)
        await asyncio.sleep(0.3)

        # Verify initial status received in FM
        r_rec = loop.core.tracker.get_robot("robot_1")
        assert r_rec.session_id == str(sess_1)
        assert r_rec.initial_status_verified is True
        assert r_rec.session_blocked is False

        station = {"station_id": "dock", "robot_id": "robot_1"}
        assert await loop.submit(Event("RESERVE", station)) == "APPLIED"
        msg1.status_seq = 2
        msg1.state = RobotState.STATE_ERROR
        msg1.header.stamp = pub_node.get_clock().now().to_msg()
        pub.publish(msg1)
        await asyncio.sleep(0.3)
        assert await loop.submit(Event("UNBLOCK", station)) == "REJECTED"

        msg1.status_seq = 3
        msg1.state = RobotState.STATE_IDLE
        msg1.pose.pose.position.x = 1.0
        msg1.pose.header.stamp = pub_node.get_clock().now().to_msg()
        msg1.header.stamp = pub_node.get_clock().now().to_msg()
        pub.publish(msg1)
        await asyncio.sleep(0.3)
        assert await loop.submit(Event("UNBLOCK", station)) == "APPLIED"

        # Send second message with changed session UUID (Executor restart!)
        sess_2 = uuid.uuid4()
        msg2 = RobotStatus()
        msg2.robot_id = "robot_1"
        msg2.status_seq = 1
        msg2.publisher_session_id = RosUUID(uuid=list(sess_2.bytes))
        msg2.current_epoch = 0
        msg2.state = RobotState.STATE_IDLE
        msg2.current_phase = 0
        msg2.is_loaded = False
        msg2.pose.header.frame_id = "map"
        msg2.battery_soc_percent = 90.0
        msg2.battery_energy_wh = 90.0
        msg2.current_task_id = ""
        msg2.header.stamp = pub_node.get_clock().now().to_msg()

        pub.publish(msg2)
        await asyncio.sleep(0.3)

        # Verify robot entered SESSION_BLOCKED
        r_rec2 = loop.core.tracker.get_robot("robot_1")
        assert r_rec2.session_blocked is True

        await loop.close()
        executor.shutdown()
        node.destroy_node()
        pub_node.destroy_node()
        store.close()

    try:
        asyncio.run(scenario())
    finally:
        rclpy.shutdown()


@pytest.mark.parametrize("epoch_offset", [0, None, 1], ids=["matching", "unset", "mismatched"])
def test_ros2_execute_task_action_client_terminal_epoch(tmp_path, epoch_offset):
    """Verify the result's wire epoch and goal UUID through the real ROS 2 adapter."""
    rclpy.init()
    fm_node = Node("test_fm_action_node")
    server_node = Node("test_executor_server_node")

    db_path = str(tmp_path / "test_ros2_action.db")
    store = SQLiteStore(db_path)
    core = FleetManagerCore(MockRoutes(), Pose2D())
    core.register_robot("robot_1")

    # Set up mock ActionServer on server_node
    received_goal_uuids = []
    
    def goal_callback(goal_request):
        return GoalResponse.ACCEPT

    def cancel_callback(goal_handle):
        return CancelResponse.ACCEPT

    async def execute_callback(goal_handle):
        u_str = str(uuid.UUID(bytes=bytes(goal_handle.goal_id.uuid)))
        received_goal_uuids.append(u_str)

        # Send feedback
        fb = ExecuteTask.Feedback()
        fb.current_phase = 1
        fb.distance_to_goal = 5.0
        fb.battery_soc = 89.0
        goal_handle.publish_feedback(fb)

        res = ExecuteTask.Result()
        res.status = int(TaskResultStatus.STATUS_SUCCEEDED)
        # An unset uint64 is transmitted as zero.
        if epoch_offset is not None:
            res.completed_epoch = goal_handle.request.assignment_epoch + epoch_offset
        res.error_reason = ""
        goal_handle.succeed()
        return res

    act_server = ActionServer(
        server_node,
        ExecuteTask,
        "/robot_1/execute_task",
        execute_callback=execute_callback,
        goal_callback=goal_callback,
        cancel_callback=cancel_callback,
    )

    async def scenario():
        loop = FleetEventLoop(store, core)
        await loop.start()

        # Initial status
        await loop.submit(Event("ROBOT_STATUS", {
            "robot_id": "robot_1", "status_seq": 1, "publisher_session_id": str(uuid.uuid4()),
            "current_epoch": 0, "state": 1, "current_phase": 0, "is_loaded": False,
            "pose": Pose2D(), "battery_soc_percent": 100, "battery_energy_wh": 100,
            "current_task_id": None, "timestamp_sec": 10.0,
        }))

        # Submit and assign task
        await loop.submit(Event("SUBMIT_TASK", {
            "task_id": "task_ros2", "pickup_pose": Pose2D(1, 0), "dropoff_pose": Pose2D(2, 0),
            "priority": TaskPriority.PRIORITY_MEDIUM, "created_at": 10.0,
        }))
        await loop.submit(Event("TICK", {"current_time": 10.0}))

        task = loop.core._active_tasks["task_ros2"]
        target_uuid = task.goal_uuid

        adapter = FleetROS2Adapter(
            node=fm_node,
            consumer=loop,
            loop=asyncio.get_running_loop(),
            robot_ids=["robot_1"],
        )

        executor = SingleThreadedExecutor()
        executor.add_node(fm_node)
        executor.add_node(server_node)

        spin_thread = threading.Thread(target=executor.spin, daemon=True)
        spin_thread.start()

        # Outbox dispatcher dispatches EXECUTE_TASK
        dispatcher = OutboxDispatcher(
            consumer=loop,
            sender=adapter.outbox_sender,
            clock=time.monotonic,
            retry_delay=2.0,
        )

        try:
            assert await dispatcher.send_one() is True
            deadline = time.monotonic() + 5
            result = None
            while result is None and time.monotonic() < deadline:
                result = store.connection.execute(
                    "SELECT outcome FROM processed_events WHERE goal_uuid=? AND stream IS NULL",
                    (target_uuid,),
                ).fetchone()
                if result is None:
                    await asyncio.sleep(0.01)

            assert received_goal_uuids == [target_uuid]
            assert result is not None
            persisted = store.connection.execute(
                "SELECT status, assignment_epoch, goal_uuid FROM tasks WHERE task_id='task_ros2'"
            ).fetchone()
            if epoch_offset == 0:
                assert result["outcome"] == "APPLIED"
                assert "task_ros2" in loop.core._completed_tasks
                assert persisted["status"] == "COMPLETED"
            else:
                assert result["outcome"] == "STALE"
                assert loop.core._active_tasks["task_ros2"].goal_uuid == target_uuid
                assert persisted["status"] in ("ASSIGNED", "EXECUTING")
            assert (persisted["assignment_epoch"], persisted["goal_uuid"]) == (
                task.assignment_epoch, target_uuid,
            )
        finally:
            await loop.close()
            executor.shutdown()
            spin_thread.join(timeout=5)
            act_server.destroy()
            fm_node.destroy_node()
            server_node.destroy_node()
            store.close()

    try:
        asyncio.run(scenario())
    finally:
        rclpy.shutdown()


def test_ros2_clear_robot_error_service_call(tmp_path):
    """Verify real ClearRobotError service communication."""
    rclpy.init()
    fm_node = Node("test_fm_srv_node")
    server_node = Node("test_executor_srv_node")

    received_requests = []

    def clear_srv_cb(request, response):
        received_requests.append((request.robot_id, request.expected_epoch))
        response.accepted = True
        response.reason = "Cleared by test operator"
        response.resulting_state = RobotState.STATE_IDLE
        return response

    srv = server_node.create_service(ClearRobotError, "/robot_1/clear_robot_error", clear_srv_cb)

    async def scenario():
        client_bridge = ClearRobotErrorServiceClient(
            robot_id="robot_1",
            service_client=fm_node.create_client(ClearRobotError, "/robot_1/clear_robot_error"),
        )

        executor = SingleThreadedExecutor()
        executor.add_node(fm_node)
        executor.add_node(server_node)

        spin_thread = threading.Thread(target=executor.spin, daemon=True)
        spin_thread.start()

        resp = await client_bridge.clear_error(expected_epoch=7)
        assert resp.accepted is True
        assert resp.reason == "Cleared by test operator"
        assert len(received_requests) == 1
        assert received_requests[0] == ("robot_1", 7)

        executor.shutdown()
        srv.destroy()
        fm_node.destroy_node()
        server_node.destroy_node()

    try:
        asyncio.run(scenario())
    finally:
        rclpy.shutdown()


def test_live_routes_use_configured_namespaces_and_distinct_planner_paths(tmp_path):
    from nav2_msgs.action import ComputePathToPose
    from backend.fleet_manager.adapters.route_cache import CachedRouteDistanceProvider, RouteCache

    rclpy.init()
    fm_node = Node("test_fm_live_routes")
    server_node = Node("test_namespaced_planners")
    executor = SingleThreadedExecutor()
    executor.add_node(fm_node)
    executor.add_node(server_node)
    thread = threading.Thread(target=executor.spin, daemon=True)

    namespaces = {"r1": "/west", "r2": "/east"}
    requests = {"r1": [], "r2": []}

    def make_planner(robot_id, detour):
        def plan(handle):
            request = handle.request
            start, goal = request.start, request.goal
            requests[robot_id].append((start.pose.position.x, goal.pose.position.x, request.use_start))
            middle = PoseStamped()
            middle.header.frame_id = "map"
            middle.pose.position.x = (start.pose.position.x + goal.pose.position.x) / 2
            middle.pose.position.y = detour
            result = ComputePathToPose.Result()
            result.path.header.frame_id = "map"
            result.path.poses = [start, middle, goal]
            handle.succeed()
            return result
        return ActionServer(server_node, ComputePathToPose,
                            f"{namespaces[robot_id]}/compute_path_to_pose", plan)

    servers = [make_planner("r1", 5.0), make_planner("r2", 0.0)]
    store = SQLiteStore(tmp_path / "ros_routes.db")
    core = FleetManagerCore(CachedRouteDistanceProvider(RouteCache()), Pose2D(3, 0))
    for robot_id in namespaces:
        core.register_robot(robot_id)
    thread.start()

    async def scenario():
        loop = FleetEventLoop(store, core)
        adapter = FleetROS2Adapter(fm_node, loop, asyncio.get_running_loop(), list(namespaces),
                                   robot_namespaces=namespaces)
        await loop.start()
        try:
            # Planner servers can take a moment to appear in the DDS graph.
            deadline = time.monotonic() + 5
            while not all(client.server_is_ready()
                          for client in adapter.route_resolver._action_clients.values()):
                assert time.monotonic() < deadline
                await asyncio.sleep(0.02)

            for robot_id in namespaces:
                await loop.submit(Event("ROBOT_STATUS", {
                    "robot_id": robot_id, "status_seq": 1, "publisher_session_id": str(uuid.uuid4()),
                    "current_epoch": 0, "state": 1, "current_phase": 0, "is_loaded": False,
                    "pose": Pose2D(), "battery_soc_percent": 100, "battery_energy_wh": 100,
                    "current_task_id": None, "timestamp_sec": time.monotonic(),
                }))
            assert len(adapter.route_cache) == 0
            await loop.submit(Event("SUBMIT_TASK", {
                "task_id": "live_route", "pickup_pose": Pose2D(1, 0), "dropoff_pose": Pose2D(2, 0),
                "priority": TaskPriority.PRIORITY_LOW, "created_at": time.monotonic(),
            }))
            deadline = time.monotonic() + 2
            while "live_route" not in loop.core._active_tasks:
                assert time.monotonic() < deadline, requests
                await asyncio.sleep(0.02)

            assert loop.core._active_tasks["live_route"].assigned_robot_id == "r2"
            assert requests == {robot: [(0, 1, True), (1, 2, True), (2, 3, True)] for robot in namespaces}
            assert store.connection.execute("SELECT COUNT(*) FROM outbox_events").fetchone()[0] == 1
        finally:
            await loop.close()

    try:
        asyncio.run(scenario())
    finally:
        store.close()
        executor.shutdown()
        thread.join(timeout=5)
        for server in servers:
            server.destroy()
        fm_node.destroy_node()
        server_node.destroy_node()
        rclpy.shutdown()
